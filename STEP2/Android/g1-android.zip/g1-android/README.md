npm install
npx react-native start
npx react-native run-android